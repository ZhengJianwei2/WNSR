function q=minor_swap(p,m,n)
% 1:(m*n) is swapped into [m, 1:(m-1), 2*m, (m+1):(2*m-1), ...]
% not yet optimized
q=zeros(m*n,1);
for i=1:n
    q((i-1)*m+1)=p(i*m);
    q((i-1)*m+2:i*m)=p((i-1)*m+1:i*m-1);
end
