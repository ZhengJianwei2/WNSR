function W_new=assemble_weight_new(W,px,py,m,n)
r=m*n;
major_idx=(1:r)';
W_new=sparse(r,r);
for jj=1:py
    if jj>1
        major_idx=major_swap(major_idx,m,n);
    end
    for ii=1:px
        if ii==1
            idx=major_idx;
        else
            idx=minor_swap(idx,m,n);
        end
        left=sparse(1:r,idx,1,r,r);
        right=sparse(idx,1:r,1,r,r);
        W_temp=left*W*right;
        %{
        W_temp(:,1:r)=W_temp(:,idx);
        toc
        tic
        W_temp(1:r,:)=W_temp(idx,:);
        toc
        %}
        W_new=W_new+W_temp;
    end
end