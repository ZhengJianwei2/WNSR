run toolbox\vl_setup
close all
clear
clc
addpath('lowrank');
addpath('lowrank/PROPACKmod/');
addpath('lowrank/solver');
load WDCmall.mat

name = 'WNSR';

[m,n,Bi] = size(Hw);
gt=Hw;
%%%%%%%%%%%%%%%%%%%%%%%%%% Normalization %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for i =1:Bi
y_MINDN(i) = min(reshape(y(:,:,i),m*n,1));
y_MAXDN(i) = max(reshape(y(:,:,i),m*n,1));
Int1(i) = y_MAXDN(i) - y_MINDN(i);
y(:,:,i) = (y(:,:,i) - y_MINDN(i))/Int1(i);

MINDN(i) = min(reshape(Hw(:,:,i),m*n,1));
MAXDN(i) = max(reshape(Hw(:,:,i),m*n,1));
Int2(i) = MAXDN(i) - MINDN(i);
Hw(:,:,i) = (Hw(:,:,i) - MINDN(i))/Int2(i);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% low rank initialization
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
t1=clock;
test_lowrank
t2=clock;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% parameters refinement
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
rate=0.05;
mu = 1/rate -1; 
gamma=1/rate;      
px=2;                                       % patch size
py=2;
ms = 20;
ms_normal=10;
scale_target=0;
outerloop=1;                                %1 iteration of WNSR
lambda = 1e8;  % data fidelity
beta=0.05;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% WNSR %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
t1=clock;
[result_WNSR] = WNSR_WGL_noisy_HSI(y,id_matrix_v,mu,lambda,outerloop,px,py,ms,...
ms_normal,Hw,scale_target,result_lowrank,name,gamma,beta);
t2=clock;
time_WNSR=etime(t2,t1);

%%%%%%%%%%%%%%%%%%%%%%%%%% Inverse Normalization %%%%%%%%%%%%%%%%%%%%%%
for i =1:Bi
u(:,:,i)=result_WNSR(:,:,i)*Int1(i)+y_MINDN(i);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

temp=sum(((u(:)-gt(:)).^2))/m/n/Bi;
psnr_wnsr = 10*log((max(gt(:)).^2/temp))/log(10);

figure
imshow(result_WNSR(:,:,60),[0 max(Hw(:))])

% save(['result_' num2str(rate) '_' name '.mat'],'result_WNSR','time_WNSR');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%