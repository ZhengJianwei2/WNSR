function [out] = WNSR_WGL_noisy_HSI(y,mask,mu,lambda,outerloop,px,py,ms,...
    ms_normal,H,scale_target,result_lowrank,~,gamma,beta)

[m,n,B] = size(H);
r=m*n;
u=result_lowrank;
scale = scale_target;

for ii = 1: outerloop
    patch = image2patch_3d_local(u,px,py,scale*0,max(H(:)));    
    W=weight_ann_local(patch,ms,ms_normal,2^10);    
    W=max(W,W');
    W=assemble_weight_new(W,px,py,m,n);    
    fprintf('sparsity = %f \n',nnz(W)/size(W,1)^2)
    D=sum(W,2);
    D=sparse(1:r,1:r,D,r,r);
    L=D-W;
    LAP=2*L;
    for jj=1:B
        id_p=reshape(mask(:,:,jj),r,1);
        id=find(id_p);
        id_c=find(~id_p);
        d=zeros(r,1);
        d(id)=gamma;
        d(id_c)=1;
        temp_mat= sparse(id,id,1,r,r);
        W0=W*temp_mat;
        D0=sum(W0,2);
        D0=sparse(1:r,1:r,D0,r,r);
        L0=D0-W0;
        
        b=lambda*temp_mat*reshape(y(:,:,jj),[],1);
        mat = 2*L+mu*L0+mu*temp_mat*L + lambda*temp_mat;
        
           [temp,flag,relres,iter] = gmres(mat,b,[],1e-8,500,[],[],reshape(u(:,:,jj),[],1));
        fprintf('step = %d, band = %d, flag = %d, relres = %f, iter = %d \n',ii,jj,flag,relres,iter(2))
        u(:,:,jj)=reshape(temp,m,n);
    end
    

end
out = u;

    function y = BiH(u1)
        y = (LAP*(d.*(LAP*u1)));
        y = beta*y+mat*u1;
    end

end
