function patch=image2patch_2d(u,px,py)
% u is the 2d image
% px, py are the patch sizes
[m,n]=size(u);
pad_u=padarray(u,[px,py],'circular','post');
patch=zeros(px*py,m*n);
for i=1:px
    for j=1:py
        temp=pad_u(i:(i+m-1),j:(j+n-1));
        patch(i+(j-1)*px,:)=reshape(temp,1,[]);
    end
end
